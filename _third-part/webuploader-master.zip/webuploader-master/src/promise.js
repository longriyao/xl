/**
 * @fileOverview Promise/A+
 */
define([
    './promise-third'
], function( _ ) {
    return _;
});