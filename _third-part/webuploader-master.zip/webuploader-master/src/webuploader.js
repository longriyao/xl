/**
 * @fileOverview Uploader上传类
 */
define([
    './preset/all',
    './widgets/log'
], function( preset ) {
    return preset;
});